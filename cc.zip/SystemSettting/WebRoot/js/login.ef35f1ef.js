/**
 * Created by aniu on 2016/7/18.
 */

(function (window, $) {
    var SID;
    function  login() {
        $J_login = $('.J_mwarp');
        this.addtel = $J_login.find('#logintel');
        this.logincode = this.addtel.find('#logincode');
        this.getcode = $J_login.find('.getcode');
        this.opencode = $J_login.find('.opencode');
        this.loginwxcode = $J_login.find('.J_login_code');
        this.loginpc = $J_login.find('.J_login_pc');
        this.wxcode = $J_login.find('.wx_code');
        this._init();
    }

    login.prototype= {
        _init:function () {
            var _this = this;
            _this._addEvent();
        },          
       //登录
        _loginajax:function (username,password) {
            var loginData = {
                name:username,
                password:password
            }
            $.ajax({
                contentType: "application/x-www-form-urlencoded; charset=utf-8",
                url:"user/login",
                type : "POST",
                data :loginData,
                success : function(remoteData) {
                    if(remoteData.codeId==1){
                    	window.location.href="view/main?roleId="+remoteData.data.roleId
                    }else{
                        Utils.showTip(remoteData.codeDes)
                    }
                },
                error:function(data){
					Utils.showTip(data)
                }
            });
        },
        _addEvent:function () {
            var _this = this;
            var $el = $(document);
            this.addtel.blur(function () {
                _this._tel();
            });
            this.logincode.blur(function () {
                var tel = this.val();
                _this._code(tel);
            });
            this.getcode.blur(function () {
                var _this = this;
                var tel = this.logincode.val();
                _this._ajax(tel);
            });
            $el.on('click','.wx_code',function (e) {
                $('.J_login_code').removeClass('none');
                $('.J_login_pc').addClass('none');
            });
            $el.on('click','.pc_code',function (e) {
                $('.J_login_code').addClass('none');
                $('.J_login_pc').removeClass('none');
            });
           $('.J_btn').on('click',function () {
                var  username = $('#username').val();
                var  password  = $('#pwd').val();
               _this._loginajax(username,password)
            })
        }
    };
    window.login = login;
})(window, $);
 