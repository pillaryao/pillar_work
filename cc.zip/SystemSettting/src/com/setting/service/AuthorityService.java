package com.setting.service;

import java.util.List;
import java.util.Map;

import com.setting.entity.Authority;


public interface AuthorityService {

	/**
	 * 查询角色的拥有的权限
	 * @param roleId
	 * @return
	 */
	List<Authority> findByRoleId(Long roleId) throws Exception;
	
	/**
	 * 查询所有权限
	 * @return
	 * @throws Exception
	 */
	List<Map<String,Object>> findAllAuthority() throws Exception;
	/**
	 * 添加角色的权限
	 * @param roleId
	 * @param authorityId
	 * @return
	 * @throws Exception
	 */
	Integer addRolePower(Long roleId,Long authorityId) throws Exception;
}
