package com.setting.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.setting.dao.RoleMapper;
import com.setting.entity.Authority;
import com.setting.entity.Role;
import com.setting.service.RoleService;
@Service
public class RoleServiceImpl implements RoleService{
	@Autowired
	private RoleMapper roleMapper;
	@Override
	public Integer add(String roleName) throws Exception {
		// TODO Auto-generated method stub
		return roleMapper.add(roleName);
	}
	@Override
	public Integer update(Role role) throws Exception {
		// TODO Auto-generated method stub
		return roleMapper.update(role);
	}
	@Override
	public Integer delete(Long id) throws Exception {
		// TODO Auto-generated method stub
		return roleMapper.delete(id);
	}
	@Override
	public List<Role> findAll() throws Exception {
		// TODO Auto-generated method stub
		return roleMapper.findAll();
	}
}
