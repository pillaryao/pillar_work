package com.setting.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.setting.dao.PartMapper;
import com.setting.service.PartService;

@Service
public class PartServiceImpl implements PartService{

	@Autowired
	private PartMapper partMapper;
	@Override
	public Integer addPartition(String partName) throws Exception {
		// TODO Auto-generated method stub
		return partMapper.addPartition(partName);
	}

	@Override
	public List<Map<String, Object>> findAll() throws Exception {
		// TODO Auto-generated method stub
		return partMapper.findAll();
	}
}
