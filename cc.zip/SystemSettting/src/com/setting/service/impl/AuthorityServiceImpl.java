package com.setting.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.setting.dao.AuthorityMapper;
import com.setting.entity.Authority;
import com.setting.service.AuthorityService;
@Service
public class AuthorityServiceImpl implements AuthorityService{
	@Autowired
	private AuthorityMapper authorityMapper;
	@Override
	public List<Authority> findByRoleId(Long roleId) throws Exception {
		// TODO Auto-generated method stub
		return authorityMapper.findByRoleId(roleId);
	}

	@Override
	public List<Map<String, Object>> findAllAuthority() throws Exception {
		
		return authorityMapper.findAllAuthority();
	}

	@Override
	public Integer addRolePower(Long roleId, Long authorityId) throws Exception {
			Integer result = authorityMapper.addRolePower(roleId, authorityId);
			if(result!=null&&result>0)
				return result;
		return null;
	}

}
