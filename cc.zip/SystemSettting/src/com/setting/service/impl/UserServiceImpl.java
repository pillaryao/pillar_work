package com.setting.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.setting.dao.UserMapper;
import com.setting.entity.User;
import com.setting.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserMapper userMapper;
	@Override
	public User login(String name, String password) throws Exception {
		return userMapper.login(name, password);
	}
	@Override
	public Integer add(User user) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.add(user);
	}
	@Override
	public Integer delete(Long id) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.delete(id);
	}
	@Override
	public Integer updatePassword(String newPwd, String oldPwd, Long id)
			throws Exception {
		User user = userMapper.findById(id);
		if(user!=null&&user.getPassword().equals(oldPwd)){
			return userMapper.updatePassword(newPwd, id);
		}
		return null;
	}

}
