package com.setting.service;

import java.util.List;
import java.util.Map;

import com.setting.entity.Authority;
import com.setting.entity.Role;

public interface RoleService {
	
	/**
	 * 添加角色
	 * @param roleName
	 * @return
	 */
	Integer add(String roleName) throws Exception;
	/**
	 * 编辑角色
	 * @param role
	 * @return
	 * @throws Exception
	 */
	Integer update(Role role) throws Exception;
	/**
	 * 删除角色
	 * @param id
	 * @return
	 * @throws Exception
	 */
	Integer delete(Long id) throws Exception;
	
	/**
	 * 查询所有角色
	 * @return
	 * @throws Exception
	 */
	List<Role> findAll() throws Exception;
	
	
}
