package com.setting.service;

import java.util.List;
import java.util.Map;

public interface PartService {
	/**
	 * 添加分区
	 * @param partName
	 * @return
	 * @throws Exception
	 */
	Integer addPartition(String partName) throws Exception;
	/**
	 * 查询所有分区
	 * @return
	 * @throws Exception
	 */
	List<Map<String,Object>> findAll() throws Exception;
	
	
}
