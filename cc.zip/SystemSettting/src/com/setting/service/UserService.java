package com.setting.service;

import java.util.List;

import com.setting.entity.Authority;
import com.setting.entity.User;

public interface UserService {
	/**
	 * 登录
	 * @param name
	 * @param password
	 * @return
	 */
	User login(String name,String password) throws Exception;
	/**
	 * 添加用户
	 * @param user
	 * @return
	 */
	Integer add(User user) throws Exception;
	/**
	 * 删除用户
	 * @param id
	 * @return
	 * @throws Exception
	 */
	Integer delete(Long id) throws Exception;
	/**
	 * 修改密码
	 * @param newPwd
	 * @param oldPwd
	 * @param id
	 * @return
	 */
	Integer updatePassword(String newPwd,String oldPwd,Long id) throws Exception;
}
