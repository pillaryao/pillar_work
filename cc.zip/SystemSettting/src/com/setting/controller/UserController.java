package com.setting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.setting.entity.ResponseData;
import com.setting.entity.User;
import com.setting.enums.ResponseEnum;
import com.setting.service.UserService;

@Controller
@RequestMapping(value="/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	@ResponseBody
	public ResponseData<User> login(@RequestParam("name")String name,@RequestParam("password")String password){
		User user;
		try {
			user = userService.login(name, password);
			if(user==null)
				return new ResponseData<User>(ResponseEnum.LOGIN_FAILED);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<User>(ResponseEnum.FAILED);
		}
		System.out.println("用户登录"+user);
		return new ResponseData<User>(ResponseEnum.SUCCESS,user);
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	@ResponseBody
	public ResponseData<Object> delete(@RequestParam("id")Long id){
		try {
			Integer result = userService.delete(id);
			if(result==null||result<=0)
				return new ResponseData<Object>(ResponseEnum.FAILED);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<Object>(ResponseEnum.FAILED);
		}
		System.out.println("删除用户"+id);
		return new ResponseData<Object>(ResponseEnum.SUCCESS,null);
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	@ResponseBody
	public ResponseData<Object> add(@RequestParam("roleId")Long roleId,@RequestParam("name")String name,@RequestParam("password")String password){
		User user=new User();
		user.setRoleId(roleId);
		user.setName(name);
		user.setPassword(password);
		System.out.println("添加用户"+user);
		try {
			Integer result = userService.add(user);
			if(result==null||result<=0)
				return new ResponseData<Object>(ResponseEnum.FAILED);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<Object>(ResponseEnum.FAILED);
		}
		return new ResponseData<Object>(ResponseEnum.SUCCESS,null);
	}
	
	@RequestMapping(value="/newPwd",method=RequestMethod.POST)
	@ResponseBody
	public ResponseData<Object> updatePassword(@RequestParam("id")Long id,@RequestParam("oldPwd")String oldPwd,@RequestParam("newPwd")String newPwd){
		try {
			Integer result = userService.updatePassword(newPwd, oldPwd, id);
			if(result==null||result<=0)
				return new ResponseData<Object>(ResponseEnum.ERROR_PWD);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<Object>(ResponseEnum.FAILED);
		}
		System.out.println("修改密码");
		return new ResponseData<Object>(ResponseEnum.SUCCESS,null);
	}
}

