package com.setting.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.setting.entity.Authority;
import com.setting.entity.ResponseData;
import com.setting.entity.Role;
import com.setting.enums.ResponseEnum;
import com.setting.service.RoleService;

@Controller
@RequestMapping("/role")
public class RoleController {
	@Autowired
	private RoleService roleService;

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@ResponseBody
	public ResponseData<Object> addRole(
			@RequestParam("roleName") String roleName) {
		try {
			System.out.println("添加角色" + roleName);
			Integer result = roleService.add(roleName);
			if (result != null)
				return new ResponseData<Object>(ResponseEnum.SUCCESS, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseData<Object>(ResponseEnum.EXIST_OR_FAILED);

	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	@ResponseBody
	public ResponseData<Object> update(@RequestParam(value="id")Long id,
			@RequestParam(required=false,value="roleName") String roleName) {
		try {
			Role role= new Role();
			role.setId(id);
			role.setRoleName(roleName);
			System.out.println("编辑角色" + role);
			Integer result = roleService.update(role);
			if (result == null)
				return new ResponseData<Object>(ResponseEnum.EXIST_OR_FAILED);
			if(result==0)
				return new ResponseData<Object>(ResponseEnum.EXIST_OR_FAILED);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseData<Object>(ResponseEnum.SUCCESS, null);
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	@ResponseBody
	public ResponseData<Object> delete(@RequestParam(value="id")Long id) {
		try {
			System.out.println("删除角色" + id);
			Integer result = roleService.delete(id);
			if (result == null||result==0)
				return new ResponseData<Object>(ResponseEnum.FAILED);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<Object>(ResponseEnum.FAILED);
		}
		return new ResponseData<Object>(ResponseEnum.SUCCESS, null);
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	@ResponseBody
	public ResponseData<List<Role>> findAll() {
		List<Role> list = null;
		try {
			  list = roleService.findAll();
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<List<Role>>(ResponseEnum.FAILED);
		}
		System.out.println("查询所有角色"+list);
		return new ResponseData<List<Role>>(ResponseEnum.SUCCESS, list);
	}
	
}
