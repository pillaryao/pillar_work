package com.setting.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.setting.entity.Authority;
import com.setting.entity.ResponseData;
import com.setting.entity.Role;
import com.setting.enums.ResponseEnum;
import com.setting.service.AuthorityService;

@Controller
@RequestMapping("/authority")
public class AuthorityController {
	@Autowired
	private AuthorityService authorityService;

	@RequestMapping(value = "/findByRoleId", method = RequestMethod.GET)
	@ResponseBody
	public ResponseData<List<Authority>> findRoleAuthority(@RequestParam("roleId")Long roleId) {
		List<Authority> list = null;
		try {
			  list = authorityService.findByRoleId(roleId);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<List<Authority>>(ResponseEnum.FAILED);
		}
		System.out.println("查询角色拥有的权限"+list);
		return new ResponseData<List<Authority>>(ResponseEnum.SUCCESS, list);
	}
	
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseData<List<Map<String, Object>>> findAll() {
		List<Map<String, Object>> list=null;
		try {
			  list = authorityService.findAllAuthority();
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<List<Map<String, Object>>>(ResponseEnum.FAILED);
		}
		System.out.println("查询所有权限"+list);
		return new ResponseData<List<Map<String, Object>>>(ResponseEnum.SUCCESS, list);
	}
	
	@RequestMapping(value = "/add/rolePower", method = RequestMethod.POST)
	@ResponseBody
	public ResponseData<Object> addRolePower(@RequestParam("roleId")Long roleId,@RequestParam("authorityId")Long authorityId){
		try {
			Integer result = authorityService.addRolePower(roleId, authorityId);
			if(result!=null)
				return new ResponseData<Object>(ResponseEnum.SUCCESS, null);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<Object>(ResponseEnum.FAILED);
		}
		System.out.println("给角色添加权限");
		return new ResponseData<Object>(ResponseEnum.FAILED);
	}
}
