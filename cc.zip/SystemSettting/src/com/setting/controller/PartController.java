package com.setting.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.setting.entity.Authority;
import com.setting.entity.ResponseData;
import com.setting.entity.Role;
import com.setting.enums.ResponseEnum;
import com.setting.service.AuthorityService;
import com.setting.service.PartService;

@Controller
@RequestMapping("/part")
public class PartController {
	@Autowired
	private PartService partService;

	@RequestMapping(value = "/findAll", method = RequestMethod.GET)
	@ResponseBody
	public ResponseData<List<Map<String,Object>>> findAll() {
		List<Map<String,Object>> list = null;
		try {
			  list = partService.findAll();
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<List<Map<String,Object>>>(ResponseEnum.FAILED);
		}
		System.out.println("查询拥有的分区"+list);
		return new ResponseData<List<Map<String,Object>>>(ResponseEnum.SUCCESS, list);
	}
	
	@RequestMapping(value = "/addPartition", method = RequestMethod.POST)
	@ResponseBody
	public ResponseData<Object> addPartition(@RequestParam("partName")String partName) {
		try {
			  Integer result = partService.addPartition(partName);
			  if(result==null||result<=0)
				  return new ResponseData<Object>(ResponseEnum.FAILED);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseData<Object>(ResponseEnum.FAILED);
		}
		System.out.println("添加分区");
		return new ResponseData<Object>(ResponseEnum.SUCCESS, null);
	}
}
