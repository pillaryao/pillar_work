package com.setting.enums; 
/** 
* @author 姚成柱
* @e-mail 347637454@qq.com
* @version 创建时间：2016年10月27日 下午5:26:58 
* @detail 
*/
public enum ResponseEnum {
	
	SUCCESS(1,"成功"),
	FAILED(-1,"失败"),
	LOGIN_FAILED(-2,"用户名密码错误!"),
	EXIST_OR_FAILED(-3,"内容已存在或添加失败"),
	ERROR_PWD(-4,"原密码错误");
	private ResponseEnum(int state, String message) {
		this.state = state;
		this.message = message;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private int state;
	private String message;
	
	public static ResponseEnum stateOf(int state){
		for (ResponseEnum e : values()) {
			if(e.getState()==state){
				return e;
			}
		}
		return null;
	}
}
