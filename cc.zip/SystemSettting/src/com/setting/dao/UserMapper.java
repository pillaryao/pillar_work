package com.setting.dao;

import org.apache.ibatis.annotations.Param;

import com.setting.entity.User;

public interface UserMapper {
	/**
	 * 登录
	 * @param name
	 * @param password
	 * @return
	 */
	User login(@Param("name")String name,@Param("password")String password) throws Exception;
	/**
	 * 添加用户
	 * @param user
	 * @return
	 */
	Integer add(User user) throws Exception;
	/**
	 * 删除用户
	 * @param id
	 * @return
	 * @throws Exception
	 */
	Integer delete(Long id) throws Exception;
	
	/**
	 * 修改密码
	 * @param newPwd
	 * @param oldPwd
	 * @param id
	 * @return
	 */
	Integer updatePassword(@Param("newPwd")String newPwd,@Param("id")Long id) throws Exception;
	/**
	 * 查找一个用户
	 * @param id
	 * @return
	 * @throws Exception
	 */
	User findById(Long id) throws Exception;
}
