package com.setting.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.setting.entity.Authority;
import com.setting.entity.Role;

public interface AuthorityMapper {

	/**
	 * 查询角色的拥有的权限
	 * @param roleId
	 * @return
	 */
	List<Authority> findByRoleId(Long roleId) throws Exception;
	
	/**
	 * 查询所有权限
	 * @return
	 * @throws Exception
	 */
	List<Map<String,Object>> findAllAuthority() throws Exception;
	
	/**
	 * 添加角色的权限
	 * @param roleId
	 * @param authorityId
	 * @return
	 * @throws Exception
	 */
	Integer addRolePower(@Param("roleId")Long roleId,@Param("authorityId")Long authorityId) throws Exception;
}
