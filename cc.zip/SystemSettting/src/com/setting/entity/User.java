package com.setting.entity;

public class User {
	
	@Override
	public String toString() {
		return "User [id=" + id + ", roleId=" + roleId + ", name=" + name
				+ ", password=" + password + "]";
	}
	private Long id;
	private Long roleId;
	private String name;
	private String password;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
