package com.setting.entity;

import com.setting.enums.ResponseEnum;

/** 
* @author 姚成柱
* @e-mail 347637454@qq.com
* @version 创建时间：2016年10月27日 下午5:21:42 
* @detail 
*/
public class ResponseData<DATA> {
	
	private int codeId;
	public int getCodeId() {
		return codeId;
	}
	public void setCodeId(int codeId) {
		this.codeId = codeId;
	}
	public String getCodeDes() {
		return codeDes;
	}
	public void setCodeDes(String codeDes) {
		this.codeDes = codeDes;
	}
	public DATA getData() {
		return data;
	}
	public ResponseData(ResponseEnum responseEnum) {
		super();
		this.codeId = responseEnum.getState();
		this.codeDes = responseEnum.getMessage();
	}
	public ResponseData(ResponseEnum responseEnum,DATA data) {
		super();
		this.codeId = responseEnum.getState();
		this.codeDes = responseEnum.getMessage();
		this.data = data;
	}
	public void setData(DATA data) {
		this.data = data;
	}
	private String codeDes;
	private DATA data;
}
