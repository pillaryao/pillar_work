package com.setting.entity;

import java.util.List;

public class Authority {
	
	private Long id;
	private Long parentId;
	private String authorityName;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getParentId() {
		return parentId;
	}
	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	public String getAuthorityName() {
		return authorityName;
	}
	public void setAuthorityName(String authorityName) {
		this.authorityName = authorityName;
	}
	private List<Authority> child;
	public List<Authority> getChild() {
		return child;
	}
	public void setChild(List<Authority> child) {
		this.child = child;
	}
}
